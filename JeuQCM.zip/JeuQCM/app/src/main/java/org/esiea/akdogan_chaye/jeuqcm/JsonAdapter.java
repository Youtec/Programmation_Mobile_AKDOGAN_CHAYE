package org.esiea.akdogan_chaye.jeuqcm;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JsonAdapter {

        public List<QuestionType> GetQuestionList(String json){

            if(json !="" || json != null)
            {
                QuestionType questionModel;
                List<QuestionType> questionsList = new ArrayList<QuestionType>();

                String  type, question, correct_answer;

                JSONObject jsonObject;
                JSONArray jsonArray, jsonArrayIncorrectAnswers;

                try {
                    jsonObject = new JSONObject(json);
                    jsonArray = jsonObject.getJSONArray("results");


                    for(int i=0; i<jsonArray.length(); i++) {
                        JSONObject jsonQuestion = jsonArray.getJSONObject(i);
                        type = jsonQuestion.getString("type");
                        question = jsonQuestion.getString("question");
                        correct_answer = jsonQuestion.getString("correct_answer");

                        List<String> all_answers = new ArrayList<String>();



                        jsonArrayIncorrectAnswers = jsonQuestion.getJSONArray("incorrect_answers");
                        for(int j=0; j<jsonArrayIncorrectAnswers.length(); j++) {
                            String s1 = jsonArrayIncorrectAnswers.getString(j);
                            s1 = s1.replace("&#039;", "\'");
                            s1 = s1.replace("&quot;","\"");
                            all_answers.add(s1);
                        }

                        //Retire les signes incompatible du Json
                        type = type.replace("&#039;", "\'");
                        type = type.replace("&quot;","\"");

                        question = question.replace("&#039;", "\'");
                        question = question.replace("&quot;","\"");

                        correct_answer = correct_answer.replace("&#039;", "\'");
                        correct_answer = correct_answer.replace("&quot;","\"");


                        all_answers.add(correct_answer);
                        Collections.shuffle(all_answers);

                        questionModel = new QuestionType( type, question, correct_answer, all_answers);
                        questionsList.add(questionModel);
                    }
                    return questionsList;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
    }


