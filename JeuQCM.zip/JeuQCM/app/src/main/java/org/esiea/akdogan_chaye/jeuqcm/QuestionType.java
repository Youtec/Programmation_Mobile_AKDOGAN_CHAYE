package org.esiea.akdogan_chaye.jeuqcm;

import java.io.Serializable;
import java.util.List;

public class QuestionType implements Serializable {



        private String type;

        private String question;
        private String correct_answer;
        private String selected_answer;
        private List<String> all_answers;

        public String getSelected_answer() {
            return selected_answer;
        }

        public void setSelected_answer(String selected_answer) {

            this.selected_answer = selected_answer;
        }

        public QuestionType(String type, String question, String correct_answer, List<String> all_answers) {

            this.type = type;
            this.question = question;
            this.correct_answer = correct_answer;
            this.all_answers = all_answers;
        }



        public String getType() {
            return type;
        }

        public String getQuestion() {
            return question;
        }

        public String getCorrect_answer() {
            return correct_answer;
        }

        public List<String> getAll_answers() {
            return all_answers;
        }
    }



