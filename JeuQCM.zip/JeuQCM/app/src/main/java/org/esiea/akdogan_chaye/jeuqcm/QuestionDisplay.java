package org.esiea.akdogan_chaye.jeuqcm;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.List;

public class QuestionDisplay extends ArrayAdapter<QuestionType> {

    public QuestionDisplay(Context context, List<QuestionType> questionList) {
        super(context,R.layout.question, questionList);
    }


    static class ViewHolder {
        TextView questionT;
        RadioButton radioBtn1, radioBtn2, radioBtn3, radioBtn4;
        TextView numberTextV;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final QuestionType question = getItem(position);
        ViewHolder viewHolder = null;

        if (convertView == null)
        {


            LayoutInflater inflater = LayoutInflater.from(getContext());
            View customView = inflater.inflate(R.layout.question, parent, false);

            viewHolder = new ViewHolder();

            viewHolder.questionT = (TextView) customView.findViewById(R.id.question_txt_v);
            viewHolder.numberTextV = (TextView) customView.findViewById(R.id.number_txt_v);

            viewHolder.radioBtn1 = (RadioButton) customView.findViewById(R.id.answer1_btn);
            viewHolder.radioBtn2 = (RadioButton) customView.findViewById(R.id.answer2_btn);
            viewHolder.radioBtn3 = (RadioButton) customView.findViewById(R.id.answer3_btn);
            viewHolder.radioBtn4 = (RadioButton) customView.findViewById(R.id.answer4_btn);

            customView.setTag(viewHolder);

            convertView = customView;

        }
        else {
            // View is being recycled, retrieve the viewHolder object from tag
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.questionT.setText(question.getQuestion());
        viewHolder.numberTextV.setText(Integer.toString(position+1) +".");

        viewHolder.radioBtn1.setText(question.getAll_answers().get(0));
        viewHolder.radioBtn2.setText(question.getAll_answers().get(1));
        viewHolder.radioBtn3.setText(question.getAll_answers().get(2));
        viewHolder.radioBtn4.setText(question.getAll_answers().get(3));

        viewHolder.radioBtn1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    question.setSelected_answer(buttonView.getText().toString());
                }
            }
        });

        viewHolder.radioBtn2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    question.setSelected_answer(buttonView.getText().toString());
                }
            }
        });

        viewHolder.radioBtn3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    question.setSelected_answer(buttonView.getText().toString());
                }
            }
        });

        viewHolder.radioBtn4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    question.setSelected_answer(buttonView.getText().toString());
                }
            }
        });

        return convertView;
    }

    @Override

    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }
}




