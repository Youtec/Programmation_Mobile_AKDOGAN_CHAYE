package org.esiea.akdogan_chaye.jeuqcm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class DisplayResult extends AppCompatActivity {

    @InjectView(R.id.correct_answers_txt_v)
    TextView correctAnswersTxt;

    @InjectView(R.id.restart_btn)
    Button restartBtn;

    @InjectView(R.id.summary_txt_v)
    TextView summaryTxt;

    String Player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        ButterKnife.inject(this);

        int PlayerPoints = getIntent().getIntExtra("PlayerPoints", 0);

        Player = getIntent().getStringExtra("Player");


        List<QuestionType> QuestionList = (List<QuestionType>) getIntent().getSerializableExtra("QuestionList");


        String correctAnswers ="Correct answers: \n \n";

        summaryTxt.setText(Player+": "+PlayerPoints+" points \n");

        for(int i=0; i<QuestionList.size(); i++)
        {
            correctAnswers += (i+1)+". "+QuestionList.get(i).getCorrect_answer()+"\n";
        }
        correctAnswersTxt.setText(correctAnswers);

        restartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restartGame();
                finish();
            }
        });
    }

    void restartGame(){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Player",Player );

        startActivity(intent);
    }
}
