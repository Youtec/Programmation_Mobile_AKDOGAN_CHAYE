package org.esiea.akdogan_chaye.jeuqcm;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import butterknife.ButterKnife;
import butterknife.InjectView;

public class LaunchGameActivity extends AppCompatActivity {

    @InjectView(R.id.btn_start)
    Button btnStart;


    @InjectView(R.id.Player)
    EditText editTextPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch_game);
        ButterKnife.inject(this);

        Button b_browser = (Button)findViewById(R.id.button_browser);

        b_browser.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1. Appeler une URL web
                String url = "https://opentdb.com/api_config.php";
                Intent intent = new Intent( Intent.ACTION_VIEW, Uri.parse( url ) );
                startActivity(intent);
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewGame(editTextPlayer.getText().toString());
            }
        });
    }
    void startNewGame(String Player){

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Player",Player );

        startActivity(intent);

    }


}
