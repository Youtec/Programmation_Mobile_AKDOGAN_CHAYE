package org.esiea.akdogan_chaye.jeuqcm;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import android.content.Intent;
import android.os.AsyncTask;

import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {


    @InjectView(R.id.questions_list)
    ListView questionV;

    @InjectView(R.id.btn_begin)
    Button beginQuizBtn;

    @InjectView(R.id.btn_check)
    Button checkQuizBtn;

    @InjectView(R.id.player_txt_v)
    TextView playerV;

    String Player;
    int PlayerPoints =0;



    List<QuestionType>  QuestionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.inject(this);

        Intent intent = getIntent();
        Player = intent.getStringExtra("Player");


        OkHttpHandler okHttpHandler = new OkHttpHandler();
        okHttpHandler.execute();


        String namePlayer = Player;

        playerV.setText("Questions for: \n"+ namePlayer);

        beginQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                populateListView();
                beginQuizBtn.setEnabled(false);
                checkQuizBtn.setEnabled(true);
            }
        });

        checkQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                beginQuizBtn.setEnabled(false);
                checkQuizBtn.setEnabled(true);
                PlayerPoints = checkAnswers(QuestionList);
                displaySummary();

            }
        });

    }

    private void displaySummary() {
        Intent intent = new Intent(this, DisplayResult.class);
        intent.putExtra("Player",Player );
        intent.putExtra("PlayerPoints", PlayerPoints);
        intent.putExtra("QuestionList", (Serializable) QuestionList);
        startActivity(intent);
        finish();
    }

    private int checkAnswers(List<QuestionType> answersToCheck) {

        int points = 0;
        for(int i=0; i<answersToCheck.size(); i++)
        {
            if(answersToCheck.get(i).getSelected_answer() == answersToCheck.get(i).getCorrect_answer())
            {
                points++;
            }
        }
        return points;
    }

    public void populateListView()
    {


        QuestionDisplay questionDisplay = new QuestionDisplay(this, QuestionList);
        questionV.setAdapter(questionDisplay);

    }

    @SuppressLint("StaticFieldLeak")
    private class OkHttpHandler extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String url = "https://opentdb.com/api.php?amount=10&type=multiple";
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder().url(url).build();
            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(final String s) {
            super.onPostExecute(s);
            JsonAdapter JsonAdapter = new JsonAdapter();
            QuestionList = JsonAdapter.GetQuestionList(s);

            beginQuizBtn.setEnabled(true);
            Toast.makeText(MainActivity.this, "Questions downloaded completed", Toast.LENGTH_SHORT).show();
        }
    }


}
